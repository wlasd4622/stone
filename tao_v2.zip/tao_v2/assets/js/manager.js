$(() => {
  let speed = localStorage.getItem('speed') || 300;
  $('input').val(speed)
  $("input").on('input', function () {
    localStorage.setItem('speed', $(this).val())
  })
})